{* Template Name:公共底部 *}
		<div id="divBottom">
			<h4 id="BlogPowerBy">Powered By {$zblogphphtml}</h4>
			<h3 id="BlogCopyRight">{$copyright}</h3>
		</div><div class="clear"></div>
	</div><div class="clear"></div>
	</div><div class="clear"></div>
</div>
{$footer}
</body>
</html>