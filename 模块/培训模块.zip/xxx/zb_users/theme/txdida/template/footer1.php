<div class="footer">
    <div class="zh">
        {if $zbp->Config('txdida')->copyon=='1'}<p>Powered By {$zblogphpabbrhtml},Theme By <a href="http://www.txcstx.cn/"  target="_blank">zblog模板</a></p>{/if}
        {$copyright}
    </div>
</div>

<script src="{$host}zb_users/theme/{$theme}/script/txdida.js" type="text/javascript"></script>
{$footer}
</body>
</html>