<?php  foreach ( $allinfo as $info) { ?>
<li><?php  echo $info['name'];  ?>:<?php  echo $info['count'];  ?></li>
<?php }   ?>