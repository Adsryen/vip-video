<?php
return array (
    'name' => '全网影视',
    'copyright' => '全网影视',
    'url' => 'http://www.全网影视/',
    'code' => '2019.03.06.1617',
    'license' => '免费版',
);
?>