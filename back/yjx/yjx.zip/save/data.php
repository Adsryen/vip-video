<?php
$url_jmp=array (
  0 => 
  array (
    'off' => 1,
    'name' => '测试连接',
    'url' => '.*?iqiyi.com.*?v_19rr5ez0zg.*?',
    'href' => 'http://qq.com-v-qq.com/20181012/7437_eea7dcd5/index.m3u8',
  ),
);
